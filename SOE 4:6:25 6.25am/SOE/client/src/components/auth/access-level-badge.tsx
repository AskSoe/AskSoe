import { AccessLevel, type AccessLevelType } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

type AccessBadgeProps = {
  accessLevel: AccessLevelType;
  className?: string;
};

export function AccessLevelBadge({ accessLevel, className = '' }: AccessBadgeProps) {
  // Determine the badge variant based on access level
  const variant = accessLevel === AccessLevel.WRITE ? "default" : "secondary";
  
  // Determine the text to display based on access level
  const badgeText = accessLevel === AccessLevel.WRITE 
    ? "Read & Write Access" 
    : "Read-only Access";
  
  return (
    <Badge 
      variant={variant} 
      className={cn("text-xs font-medium", className)}
    >
      {badgeText}
    </Badge>
  );
}