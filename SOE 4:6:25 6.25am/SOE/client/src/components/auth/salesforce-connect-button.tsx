import { useState } from "react";
import { Button } from "@/components/ui/button";
import { AccessLevel, type AccessLevelType } from "@shared/schema";
import { useSalesforceAuth } from "@/hooks/use-auth";
import { Loader2, ShieldCheck } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export function SalesforceConnectButton() {
  const [selectedAccessLevel, setSelectedAccessLevel] = useState<AccessLevelType>(AccessLevel.READ);
  const { mutate: initAuth, isPending } = useSalesforceAuth();

  const handleConnectClick = () => {
    initAuth(selectedAccessLevel);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col space-y-2">
        <label className="text-sm font-medium leading-none">
          Select Access Level
        </label>
        <Select
          value={selectedAccessLevel}
          onValueChange={(value) => setSelectedAccessLevel(value as AccessLevelType)}
          disabled={isPending}
        >
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Select Access Level" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={AccessLevel.READ}>
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4" />
                <span>Read-only Access</span>
              </div>
            </SelectItem>
            <SelectItem value={AccessLevel.WRITE}>
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4" />
                <span>Read & Write Access</span>
              </div>
            </SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Button 
        onClick={handleConnectClick} 
        disabled={isPending} 
        className="w-full"
      >
        {isPending ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Connecting...
          </>
        ) : (
          <>Connect with Salesforce</>
        )}
      </Button>
    </div>
  );
}