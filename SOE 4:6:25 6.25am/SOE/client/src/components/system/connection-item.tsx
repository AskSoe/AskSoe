import { useState } from "react";
import { System } from "@shared/schema";
import { Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface ConnectionItemProps {
  system: System;
}

export function ConnectionItem({ system }: ConnectionItemProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Status indicator color
  const statusColor = {
    connected: "bg-success-500",
    limited: "bg-warning-500",
    disconnected: "bg-error-500",
    error: "bg-error-500",
  }[system.status] || "bg-neutral-400";
  
  // Last synced text
  const lastSyncedText = system.lastSynced 
    ? `Last synced: ${formatDistanceToNow(new Date(system.lastSynced), { addSuffix: true })}`
    : system.status === "connected" 
      ? "Connected" 
      : system.status === "limited" 
        ? "Connection limited" 
        : "Disconnected";

  return (
    <>
      <div className="flex items-center py-2">
        <div className={`w-2 h-2 rounded-full ${statusColor} mr-2`}></div>
        <div className="flex-1">
          <p className="text-sm font-medium">{system.name}</p>
          <p className="text-xs text-neutral-500">{lastSyncedText}</p>
        </div>
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-8 w-8 text-neutral-400 hover:text-neutral-600"
          onClick={() => setIsDialogOpen(true)}
        >
          <Settings className="h-4 w-4" />
        </Button>
      </div>
      
      {/* System Settings Dialog */}
      <SystemSettingsDialog 
        system={system} 
        open={isDialogOpen} 
        onOpenChange={setIsDialogOpen} 
      />
    </>
  );
}

interface SystemSettingsDialogProps {
  system: System;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

function SystemSettingsDialog({ system, open, onOpenChange }: SystemSettingsDialogProps) {
  const [name, setName] = useState(system.name);
  const queryClient = useQueryClient();
  
  const updateMutation = useMutation({
    mutationFn: async (updatedSystem: Partial<System>) => {
      return apiRequest("PUT", `/api/systems/${system.id}`, updatedSystem);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ['/api/systems'],
      });
      onOpenChange(false);
    }
  });
  
  const deleteMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("DELETE", `/api/systems/${system.id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ['/api/systems'],
      });
      onOpenChange(false);
    }
  });
  
  const handleSave = () => {
    updateMutation.mutate({
      name,
      connectionDetails: system.connectionDetails
    });
  };
  
  const handleDelete = () => {
    if (confirm("Are you sure you want to disconnect this system?")) {
      deleteMutation.mutate();
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>System Connection Settings</DialogTitle>
          <DialogDescription>
            Configure your connection to {system.name}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="system-name">System Name</Label>
            <Input 
              id="system-name" 
              value={name} 
              onChange={(e) => setName(e.target.value)} 
            />
          </div>
          
          <div className="space-y-2">
            <Label>Connection Type</Label>
            <div className="text-sm px-3 py-2 border rounded-md bg-neutral-50">
              {system.type.toUpperCase()}
            </div>
          </div>
          
          <div className="space-y-2">
            <Label>Status</Label>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${
                system.status === "connected" ? "bg-success-500" : 
                system.status === "limited" ? "bg-warning-500" : 
                "bg-error-500"
              }`}></div>
              <span className="text-sm capitalize">{system.status}</span>
            </div>
          </div>
        </div>
        
        <DialogFooter className="flex justify-between">
          <Button 
            variant="destructive" 
            onClick={handleDelete}
            disabled={deleteMutation.isPending}
          >
            Disconnect
          </Button>
          <Button 
            onClick={handleSave}
            disabled={updateMutation.isPending || name === system.name}
          >
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
