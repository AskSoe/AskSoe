import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowUp } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth-context';
import { Link } from 'wouter';
import { getUserPlan } from '@/lib/userPlanUtils';
import { SubscriptionTier, SubscriptionTierType } from '@shared/schema';

interface UpgradeButtonProps {
  className?: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'default' | 'sm';
  showText?: boolean;
}

export function UpgradeButton({
  className = '',
  variant = 'default',
  size = 'default',
  showText = true,
}: UpgradeButtonProps) {
  const { isAuthenticated, username } = useAuth();
  
  // Get the user's current subscription tier from auth context
  // We'll assume 'free' if we don't have the information
  const userTierString = SubscriptionTier.FREE as SubscriptionTierType;
  const plan = getUserPlan(userTierString);
  
  // Don't show upgrade button for enterprise users
  if (userTierString === SubscriptionTier.ENTERPRISE as SubscriptionTierType) {
    return null;
  }
  
  // Determine the target upgrade tier
  const targetTier = userTierString === (SubscriptionTier.FREE as SubscriptionTierType)
    ? SubscriptionTier.PRO as SubscriptionTierType
    : SubscriptionTier.ENTERPRISE as SubscriptionTierType;
  
  return (
    <Button
      variant={variant}
      size={size}
      className={className}
      asChild
    >
      <Link href="/subscription-plans">
        <ArrowUp className="h-4 w-4 mr-2" />
        {showText && (
          <span>
            {userTierString === (SubscriptionTier.FREE as SubscriptionTierType) ? 'Upgrade to Pro' : 'Upgrade to Enterprise'}
          </span>
        )}
      </Link>
    </Button>
  );
}