import React, { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function LandingPage() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Trigger fade-in animation after component mounts
    setTimeout(() => setIsVisible(true), 100);
  }, []);

  return (
    <div className="min-h-screen w-full relative overflow-hidden flex items-center justify-center">
      {/* Sleek Modern Blue Wave Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#002B5B] via-[#05458C] to-[#002B5B]">
        <svg 
          className="absolute inset-0 w-full h-full" 
          viewBox="0 0 1440 800" 
          preserveAspectRatio="xMidYMid slice"
          style={{ minHeight: '100vh', minWidth: '100vw' }}
        >
          <defs>
            <linearGradient id="waveGrad1" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#0A66C2" stopOpacity="0.8"/>
              <stop offset="50%" stopColor="#1C86E6" stopOpacity="0.6"/>
              <stop offset="100%" stopColor="#0A66C2" stopOpacity="0.8"/>
            </linearGradient>
            <linearGradient id="waveGrad2" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#05458C" stopOpacity="0.5"/>
              <stop offset="50%" stopColor="#0A66C2" stopOpacity="0.4"/>
              <stop offset="100%" stopColor="#05458C" stopOpacity="0.5"/>
            </linearGradient>
            <linearGradient id="waveGrad3" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#002B5B" stopOpacity="0.3"/>
              <stop offset="50%" stopColor="#05458C" stopOpacity="0.2"/>
              <stop offset="100%" stopColor="#002B5B" stopOpacity="0.3"/>
            </linearGradient>
          </defs>
          
          {/* Wave Layer 1 - Bottom */}
          <path 
            d="M0,600 C360,480 720,520 1080,440 C1260,400 1350,420 1440,460 L1440,800 L0,800 Z" 
            fill="url(#waveGrad1)"
            className="animate-wave"
          />
          
          {/* Wave Layer 2 - Middle */}
          <path 
            d="M0,500 C240,380 480,420 720,360 C960,300 1200,340 1440,320 L1440,800 L0,800 Z" 
            fill="url(#waveGrad2)"
            className="animate-wave-delayed"
          />
          
          {/* Wave Layer 3 - Top */}
          <path 
            d="M0,400 C360,280 720,320 1080,240 C1260,200 1350,220 1440,260 L1440,800 L0,800 Z" 
            fill="url(#waveGrad3)"
            className="animate-wave-slow"
          />
          
          {/* Additional floating wave for top area */}
          <path 
            d="M0,200 C360,120 720,160 1080,80 C1260,40 1350,60 1440,100 L1440,400 L0,400 Z" 
            fill="url(#waveGrad3)"
            opacity="0.2"
            className="animate-wave-reverse"
          />
        </svg>
        
        {/* Dark overlay for text contrast */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/30"></div>
      </div>

      {/* Main Content */}
      <div className={`relative z-10 text-center transition-all duration-1500 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}>
        
        {/* SOE Logo/Title */}
        <div className="mb-8">
          <h1 className="text-8xl md:text-9xl font-bold tracking-wider mb-4 drop-shadow-2xl soe-title">
            SOE
          </h1>
          <div className="text-2xl md:text-3xl font-light leading-relaxed soe-subtitle">
            <div>Your Enterprise</div>
            <div>Decision Layer</div>
          </div>
        </div>

        {/* Get Started Button */}
        <div className={`transition-all duration-1500 delay-300 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}>
          <Link href="/auth">
            <Button 
              className="bg-[#F4EFE6] hover:bg-[#F4EFE6]/90 text-[#002B5B] text-xl font-semibold px-12 py-4 rounded-2xl border-2 border-[#F4EFE6] hover:border-[#F4EFE6]/80 transition-all duration-300 shadow-2xl hover:shadow-[#F4EFE6]/25 hover:scale-105"
            >
              Get Started
            </Button>
          </Link>
        </div>

        {/* Subtle tagline */}
        <div className={`mt-12 transition-all duration-1500 delay-500 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}>
          <p className="text-lg font-light soe-tagline">
            Transform your business decision making with AI-powered insights
          </p>
        </div>
      </div>

      {/* Custom CSS for wave animations and text colors */}
      <style>{`
        .soe-title {
          color: #F4EFE6 !important;
        }
        
        .soe-subtitle {
          color: #F4EFE6 !important;
        }
        
        .soe-subtitle div {
          color: #F4EFE6 !important;
        }
        
        .soe-tagline {
          color: #F4EFE6 !important;
          opacity: 0.9;
        }
        
        @keyframes wave {
          0%, 100% { transform: translateX(0) translateY(0); }
          50% { transform: translateX(-25px) translateY(-10px); }
        }
        
        @keyframes wave-delayed {
          0%, 100% { transform: translateX(0) translateY(0); }
          50% { transform: translateX(25px) translateY(-5px); }
        }
        
        @keyframes wave-slow {
          0%, 100% { transform: translateX(0) translateY(0); }
          50% { transform: translateX(-15px) translateY(-8px); }
        }
        
        @keyframes wave-reverse {
          0%, 100% { transform: translateX(0) translateY(0); }
          50% { transform: translateX(20px) translateY(5px); }
        }
        
        .animate-wave {
          animation: wave 8s ease-in-out infinite;
        }
        
        .animate-wave-delayed {
          animation: wave-delayed 10s ease-in-out infinite;
          animation-delay: 2s;
        }
        
        .animate-wave-slow {
          animation: wave-slow 12s ease-in-out infinite;
          animation-delay: 4s;
        }
        
        .animate-wave-reverse {
          animation: wave-reverse 15s ease-in-out infinite;
          animation-delay: 1s;
        }
        
        /* Mobile responsiveness */
        @media (max-width: 768px) {
          .animate-wave,
          .animate-wave-delayed,
          .animate-wave-slow,
          .animate-wave-reverse {
            animation-duration: 6s;
          }
        }
      `}</style>
    </div>
  );
}