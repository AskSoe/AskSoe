import { Router, Request, Response } from "express";
import { isAuthenticated } from "./auth";
import {
  getAllUsers,
  createUser,
  updateUser,
  deleteUser,
  User
} from "./user-storage";

export const adminRouter = Router();

// Middleware to check for admin access
const requireAdmin = (req: Request, res: Response, next: any) => {
  const user = req.user as User;
  if (user?.isAdmin) {
    return next();
  }
  return res.status(403).json({ message: "Forbidden" });
};

// Get all users
adminRouter.get("/users", isAuthenticated, requireAdmin, async (req, res) => {
  try {
    const users = await getAllUsers();
    res.json(users);
  } catch (err) {
    console.error("Failed to fetch users:", err);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Create a user
adminRouter.post("/users", isAuthenticated, requireAdmin, async (req, res) => {
  try {
    console.log("Creating user:", req.body);
    const newUser = await createUser(req.body);
    res.status(201).json(newUser);
  } catch (err) {
    console.error("Failed to create user:", err);
    res.status(500).json({ message: "Failed to create user", error: err });
  }
});

// Update a user
adminRouter.put("/users/:id", isAuthenticated, requireAdmin, async (req, res) => {
  try {
    const updated = await updateUser(parseInt(req.params.id), req.body);
    res.json(updated);
  } catch (err) {
    console.error("Failed to update user:", err);
    res.status(500).json({ message: "Failed to update user", error: err });
  }
});

// Delete a user
adminRouter.delete("/users/:id", isAuthenticated, requireAdmin, async (req, res) => {
  try {
    await deleteUser(parseInt(req.params.id));
    res.json({ success: true });
  } catch (err) {
    console.error("Failed to delete user:", err);
    res.status(500).json({ message: "Failed to delete user", error: err });
  }
});