import fs from "fs/promises";
import path from "path";
import bcrypt from "bcryptjs";

const USERS_FILE = path.resolve(__dirname, "users.json");

export interface User {
  id: number;
  name: string;
  email: string;
  username: string;
  password: string;
  accessLevel: string;
  subscriptionTier: string;
  isAdmin: boolean;
  tenantId: string;
  createdAt: string;
}

export async function readUsers(): Promise<User[]> {
  try {
    const data = await fs.readFile(USERS_FILE, "utf8");
    return JSON.parse(data);
  } catch {
    return [];
  }
}

export async function writeUsers(users: User[]) {
  await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2));
}

export async function getAllUsers(): Promise<User[]> {
  return await readUsers();
}

export async function createUser(data: Omit<User, "id" | "createdAt">): Promise<User> {
  const users = await readUsers();
  const id = users.length ? Math.max(...users.map(u => u.id)) + 1 : 1;
  const hashedPassword = await bcrypt.hash(data.password, 10);
  const newUser: User = {
    ...data,
    id,
    password: hashedPassword,
    createdAt: new Date().toISOString()
  };
  users.push(newUser);
  await writeUsers(users);
  return newUser;
}

export async function updateUser(id: number, updates: Partial<User>): Promise<User> {
  const users = await readUsers();
  const index = users.findIndex(u => u.id === id);
  if (index === -1) throw new Error("User not found");
  users[index] = { ...users[index], ...updates };
  await writeUsers(users);
  return users[index];
}

export async function deleteUser(id: number): Promise<void> {
  let users = await readUsers();
  users = users.filter(u => u.id !== id);
  await writeUsers(users);
}