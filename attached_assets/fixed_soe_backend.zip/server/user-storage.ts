import fs from 'fs/promises';
import path from 'path';

const USERS_FILE = path.resolve(__dirname, 'users.json');

export interface FileUser {
  id: number;
  name: string;
  email: string;
  tenantId: string;
  accessLevel: 'user' | 'admin';
  subscriptionTier: 'free' | 'enterprise' | 'staff_admin';
  isAdmin: boolean;
  createdAt: string;
}

async function readUsers(): Promise<FileUser[]> {
  try {
    const data = await fs.readFile(USERS_FILE, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Failed to read users.json:', err);
    return [];
  }
}

async function writeUsers(users: FileUser[]): Promise<void> {
  try {
    await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2));
  } catch (err) {
    console.error('Failed to write users.json:', err);
    throw new Error('Could not write users file');
  }
}

export async function getAllUsers(): Promise<FileUser[]> {
  return await readUsers();
}

export async function getUserByEmail(email: string): Promise<FileUser | undefined> {
  const users = await readUsers();
  return users.find(u => u.email === email);
}

export async function createUser(newUser: Omit<FileUser, 'id' | 'createdAt'>): Promise<FileUser> {
  try {
    const users = await readUsers();
    const id = users.length ? Math.max(...users.map(u => u.id)) + 1 : 1;
    const createdAt = new Date().toISOString();
    const userWithId: FileUser = { ...newUser, id, createdAt };
    users.push(userWithId);
    await writeUsers(users);
    return userWithId;
  } catch (err) {
    console.error('Error saving user:', err);
    throw new Error('Failed to save user');
  }
}

export async function updateUser(id: number, updates: Partial<FileUser>): Promise<FileUser | null> {
  const users = await readUsers();
  const index = users.findIndex(u => u.id === id);
  if (index === -1) return null;
  users[index] = { ...users[index], ...updates };
  await writeUsers(users);
  return users[index];
}

export async function deleteUser(id: number): Promise<boolean> {
  let users = await readUsers();
  const originalLength = users.length;
  users = users.filter(u => u.id !== id);
  if (users.length === originalLength) return false;
  await writeUsers(users);
  return true;
}